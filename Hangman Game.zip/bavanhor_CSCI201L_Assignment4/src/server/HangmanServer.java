package server;

import java.io.BufferedReader;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

import java.net.ServerSocket;
import java.net.Socket;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;
import java.util.Vector;

import classes.Game;
import classes.GuessRequest;
import classes.JoinGameRequest;
import classes.LogInRequest;
import classes.Result;
import classes.SignUpRequest;
import classes.StartGameRequest;
import classes.Turn;
import classes.User;
import classes.Waiting;

public class HangmanServer {
	private volatile static Vector<ServerThread> serverThreads = new Vector<ServerThread>();
	private static Map<String, String> parameters = new HashMap<>();
	private volatile static Vector<Game> games = new Vector<Game>();
	
	public HangmanServer(int port) {
		ServerSocket ss = null;
		
		// Start a ServerSocket and establish the ServerThread vector
		try {
			ss = new ServerSocket(port);
			// Continue accepting users into the hang-man game
			while(true) {
				Socket s = ss.accept();
				ServerThread st = new ServerThread(s, this);
				serverThreads.add(st);
			}
		} 
		catch(IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		} 
		finally {
			try {
				if(ss != null) {
					ss.close();
				}
			} 
			catch (IOException ioe) {
				System.out.println("ioe closing error: " + ioe.getMessage());
			}
		}
	}
	
	private boolean letterPrevGuessed(Game game, String letter) {
		for(int i = 0; i < game.getGuesses().size(); i++) {
			if(letter.equals(game.getGuesses().get(i))) {
				return true;
			}
		}
		
		return false;	
	}
	
	private Game findGame(ServerThread st) {
		Game game = null;
		
		for(int i = 0; i < games.size(); i++) {
			if(games.get(i).getUserThreads().contains(st)) {
				game = games.get(i);
			}
		}
		
		return game;
	}
	
	@SuppressWarnings("resource")
	private String generateSecretWord() {
		String secret = null;
		
		try {
			ArrayList<String> words = new ArrayList<String>();
			Scanner scan = new Scanner(new File(parameters.get("SecretWordFile")));
			
			while(scan.hasNext()) {
				words.add(scan.nextLine());
			}
			Collections.shuffle(words);
			secret = words.get(0);
		} 
		catch (FileNotFoundException cnfe) {
			cnfe.printStackTrace();
		}
	
		return secret;
	}

	private void serverPrintGuess(ServerThread st, Game game, GuessRequest gr) {
		ArrayList<String> positions = new ArrayList<String>();
		String secretDisplayed = "";
		
		for(int i = 0; i < game.getSecret().length(); i++) {
			if(game.getSecret().charAt(i) == gr.getGuess().toCharArray()[0]) {
				String pos = Integer.toString(i + 1);
				positions.add(pos);
			}
		}
		
		for(int i = 0; i < game.getSecret().length(); i++) {
			boolean found = false;
			
			for(int j = 0; j < game.getGuesses().size(); j++) {
				if(game.getSecret().substring(i, i+1).equals(game.getGuesses().get(j))) {
					found = true;
					secretDisplayed += game.getGuesses().get(j).toUpperCase() + " ";
				}
			}
			if(!found) {
				secretDisplayed += "_ ";
			}
		}
		
		System.out.print(java.time.LocalTime.now() + " " + st.getUser().getName() + " - " + gr.getGuess() + " is in " + game.getSecret() + " in position(s) ");
		
		for(int i = 0; i < positions.size(); i++) {
			if(i == positions.size() - 1) {
				System.out.print(positions.get(i) + ", ");
			}
			else if (positions.size() == 1){
				System.out.print(positions.get(i));
			}
			else {
				System.out.print("and " + positions.get(i) + ". ");
			}
		}
		
		System.out.println(" Secret word now shows " + secretDisplayed + ".");
	}

	private User updateTurns(Game game) {
		int turn = 0;
		boolean isUserTurn = false;
		
		for(int i = 0; i < game.getUserThreads().size(); i++) {
			if(game.getUserThreads().get(i).getUser().isTurn()) {
				turn = i;
				isUserTurn = true;
				
				for(int j = i + 1; j < game.getUserThreads().size(); j++) {
					if(game.getUserThreads().get(j).getUser().isPlaying()) {
						game.getUserThreads().get(i).getUser().setTurn(false);
						game.getUserThreads().get(j).getUser().setTurn(true);
						return game.getUserThreads().get(j).getUser();
					}
				}
				for(int j = 0; j < i; j++) {
					if(game.getUserThreads().get(j).getUser().isPlaying()) {
						game.getUserThreads().get(i).getUser().setTurn(false);
						game.getUserThreads().get(j).getUser().setTurn(true);
						return game.getUserThreads().get(j).getUser();
					}
				}
			}
		}
		
		if(isUserTurn) {
			return game.getUserThreads().get(turn).getUser();
		}
		else {
			return null;
		}
	}

	private int addLoss(ServerThread st) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(parameters.get("DBConnection") + "?user=" + 
					parameters.get("DBUsername") + "&password=" + 
					parameters.get("DBPassword") + "&allowPublicKeyRetrieval=true&useSSL=false");
			
			PreparedStatement ps = conn.prepareStatement("UPDATE accounts SET losses = ? WHERE username = '" + st.getUser().getName() + "'");
			ps.setInt(1, st.getUser().getLosses() + 1);
			ps.execute();
			
			int losses = st.getUser().getLosses() + 1;
			
			return losses;
		} 
		catch (SQLException sqle) {
			sqle.printStackTrace();
		} 
		catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		}
		
		return 0;
	}
	
	private int addWin(ServerThread st) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(parameters.get("DBConnection") + "?user=" + 
					parameters.get("DBUsername") + "&password=" + 
					parameters.get("DBPassword") + "&allowPublicKeyRetrieval=true&useSSL=false");
			
			PreparedStatement ps = conn.prepareStatement("UPDATE accounts SET wins = ? WHERE username = '" + st.getUser().getName() + "'");
			ps.setInt(1, st.getUser().getWins() + 1);
			ps.execute();
			
			int wins = st.getUser().getWins() + 1;
			
			return wins;
		} 
		catch (SQLException sqle) {
			sqle.printStackTrace();
		} 
		catch (ClassNotFoundException cnfe) {
			cnfe.printStackTrace();
		}
		
		return 0;
	}

	// Initialize the game for all the users playing this game
	public synchronized void loadGame(ServerThread st) {
		Game game = this.findGame(st);
		
		if(!game.isLoaded() && game != null) {
			game.setLoaded(true);
			String secret = this.generateSecretWord();
			game.setSecret(secret);
			
			User host = null;
			
			for(ServerThread s : game.getUserThreads()) {
				if(s.getUser().isHost()) {
					host = s.getUser();
				}
			}
			
			for(ServerThread s : game.getUserThreads()) {
				Turn turn = new Turn(host, game.getGuesses());
				turn.setSecret(secret);
				
				if(s.getUser().isHost()) {
					System.out.println(LocalTime.now() + " " + s.getUser().getName() + " - " + game.getName() + " has " + game.getMax() + " so starting game. Secret word is " + secret);
					turn.getPlayer().setTurn(true);
				}
				
				s.updateTurn(turn);
			}
		}
	}
		
	// Check the user's guess (letter) against the secret word
	public void guessChar(ServerThread st, GuessRequest gr) {
		Game game = this.findGame(st);
		
		System.out.println(java.time.LocalTime.now() + " " + st.getUser().getName() + " - guessed letter " + gr.getGuess());
		
		if(game.getSecret().contains(gr.getGuess())) {
			Vector<String> guesses = game.getGuesses();
			
			if(!this.letterPrevGuessed(game, gr.getGuess())) {
				guesses.add(gr.getGuess());
			}
	
			game.setGuesses(guesses);
			
			this.serverPrintGuess(st, game, gr);
			
			User currTurn = this.updateTurns(game);
			
			for(ServerThread s : game.getUserThreads()) {
				Turn turn = new Turn(currTurn, game.getGuesses());
				turn.setSecret(game.getSecret());
				turn.setNumGuesses(game.getNumGuesses());
				gr.setContains(true);
				s.receiveGuessRequest(gr);
				s.updateTurn(turn);
			}
		}
		else {
			game.setNumGuesses(game.getNumGuesses() - 1);
			
			System.out.println(LocalTime.now() + " " + st.getUser().getName() + " - " + gr.getGuess() + " is not in " + game.getSecret() + ". " + game.getName() + " now has " + game.getNumGuesses() + " guesses remaining.");
			
			if(game.getNumGuesses() == 0) {
				Result result = new Result(null);
				
				for(ServerThread s : game.getUserThreads()) {
					User user = s.getUser();
					user.setLosses(this.addLoss(s));
					user.setPlaying(false);
					result.getPlayers().add(user);
				}
				
				for(ServerThread s : game.getUserThreads()) {
					s.setPlaying(false);
					s.sendResult(result);
				}
				
				for(int i = 0; i < games.size(); i++) {
					if(games.get(i).getName().equals(game.getName())) {
						games.remove(i);
					}
				}
			}
			else {
				User currTurn = this.updateTurns(game);
				
				for(ServerThread s : game.getUserThreads()) {
					Turn turn = new Turn(currTurn, game.getGuesses());
					turn.setSecret(game.getSecret());
					turn.setNumGuesses(game.getNumGuesses());
					gr.setContains(false);
					s.receiveGuessRequest(gr);
					s.updateTurn(turn);
				}
			}
		}	
	}
	
	// Check the user's guess (word) against the secret word
	public void guessWord(ServerThread st, GuessRequest gr) {
		Game game = this.findGame(st);
		
		System.out.println(LocalTime.now() + " " + st.getUser().getName() + " - guessed word " + gr.getGuess());
		
		if(game.getSecret().equals(gr.getGuess())) {
			Result result = new Result(st.getUser());
			
			for(ServerThread s : game.getUserThreads()) {
				User user = s.getUser();
				user.setPlaying(false);
				
				if(s.equals(st)) {
					user.setWins(this.addWin(s));
					result.setWinner(user);
				}
				else {
					user.setLosses(this.addLoss(s));
				}
				
				s.setUser(user);
				result.getPlayers().add(user);
			}
			
			System.out.print(LocalTime.now() + " " + st.getUser().getName() + " - " + gr.getGuess() + " is correct. " + st.getUser().getName() + " wins game. ");
			
			if(result.getPlayers().size() != 1) {
				for(int i = 0; i < result.getPlayers().size(); i++) {
					if(!result.getPlayers().get(i).getName().equals(st.getUser().getName())) {
						if(i == (result.getPlayers().size() - 1)) {
							System.out.print(result.getPlayers().get(i).getName());
						}
						else {
							System.out.print(result.getPlayers().get(i).getName() + ", ");
						}
					}
				}
				System.out.println(" lost the game.");
			}
	
			for(ServerThread s : game.getUserThreads()) {
				s.setPlaying(false);
				s.sendResult(result);
			}
			
			for(int i = 0; i < games.size(); i++) {
				if(games.get(i).getName().equals(game.getName())) {
					games.remove(i);
				}
			}
		}
		else {
			System.out.println(LocalTime.now() + " " + st.getUser().getName() + " - " + gr.getGuess() + " is incorrect. " + st.getUser().getName() + " has lost and is no longer in the game.");
			
			game.setNumGuesses(game.getNumGuesses() - 1);
			st.getUser().setPlaying(false);
			
			boolean stillPlaying = false;
			
			for(int i = 0; i < game.getUserThreads().size(); i++) {
				if(game.getUserThreads().get(i).getUser().isPlaying()) {
					stillPlaying = true;
				}
			}
			
			if(!stillPlaying) {
				Result result = new Result(null);
				
				for(ServerThread s : game.getUserThreads()) {
					User user = s.getUser();
					user.setLosses(this.addLoss(s));
					result.getPlayers().add(user);
				}
				
				for(ServerThread s : game.getUserThreads()) {
					gr.setSecret(game.getSecret());
					gr.setContains(false);
					gr.setUser(st.getUser());
					s.receiveGuessRequest(gr);
					s.setPlaying(false);
					s.sendResult(result);
				}
				
				for(int i = 0; i < games.size(); i++) {
					if(games.get(i).getName().equals(game.getName())) {
						games.remove(i);
					}
				}
			}
			else {
				User currTurn = this.updateTurns(game);
				
				for(ServerThread s : game.getUserThreads()) {
					Turn turn = new Turn(currTurn, game.getGuesses());
					turn.setSecret(game.getSecret());
					turn.setNumGuesses(game.getNumGuesses());
					gr.setSecret(game.getSecret());
					gr.setContains(false);
					gr.setUser(st.getUser());
					s.receiveGuessRequest(gr);
					s.updateTurn(turn);
				}
			}
		}
	}
	
	public void initStart(ServerThread st, StartGameRequest sgr) {
		int numUsers = sgr.getUsers();
		String name = sgr.getName();
		// Set this ServerThread's user to host of this game
		st.getUser().setHost(true);
		
		Game game = new Game(name, numUsers);
		game.getUserThreads().add(st);
		
		Waiting w = new Waiting();
		
		if(game.getMax() == game.getUserThreads().size()) {
			game.setReady(true);
		}
		
		games.add(game);
		
		System.out.println(LocalTime.now() + " " + sgr.getUser().getName() + " - " + name + " needs " + (game.getMax() - 1) + " to start game.");
		
		w.setWaitingFor(game.getMax() - game.getUserThreads().size());
		st.receiveWaiting(w);
	}	

	public void initJoin(ServerThread st, JoinGameRequest jgr) {
		for(int i = 0; i < games.size(); i++) {
			if(games.get(i).getName().equals(jgr.getName())) {
				games.get(i).getUserThreads().add(st);
				
				Waiting w = new Waiting();
				
				for(ServerThread s : games.get(i).getUserThreads()) {
					if(!s.equals(st)) {
						st.sendUser(s.getUser());
					}
				}
				
				for(ServerThread s : games.get(i).getUserThreads()) {
					if(!s.equals(st)) {
						s.sendUser(jgr.getUser());
					}
					if(games.get(i).getMax() == games.get(i).getUserThreads().size()) {
						games.get(i).setReady(true);
					}
					else {
						System.out.println(LocalTime.now() + " " + s.getUser().getName() + " - " + games.get(i).getName() + " needs " + (games.get(i).getMax() - games.get(i).getUserThreads().size()) 
								+ " to start game.");
					}
					
					w.setWaitingFor(games.get(i).getMax() - games.get(i).getUserThreads().size());
					s.receiveWaiting(w);
				}
			}
		}
	}
	
	public void start(ServerThread st, StartGameRequest sgr) {
		System.out.println(LocalTime.now() + " " + sgr.getUser().getName() + " - wants to start a game called " + sgr.getName());
		
		boolean gameExists = false;
		
		for(int i = 0; i < games.size(); i++) {
			if(games.get(i).getName().equals(sgr.getName())) {
				gameExists = true;
			}
		}
		
		if(!gameExists) {
			System.out.println(LocalTime.now() + " " + sgr.getUser().getName() + " - successfully started game " + sgr.getName());
			
			sgr.setExists(false);
			st.receiveStartGame(sgr);
		}
		else {
			System.out.println(LocalTime.now() + " " + sgr.getUser().getName() + " - " + sgr.getName() + " already exists, so unable"
					+ " to start " + sgr.getName());
			
			sgr.setExists(true);
			st.receiveStartGame(sgr);
		}
	}
	
	public void join(ServerThread st, JoinGameRequest jgr) {
		System.out.println(java.time.LocalTime.now() + " " + jgr.getUser().getName() + " - wants to join a game called " + jgr.getName());
		
		boolean gameExists = false;
		boolean hasSpace = false;
		
		for(int i = 0; i < games.size(); i++) {
			if(games.get(i).getName().equals(jgr.getName())) {
				gameExists = true;
				
				if(games.get(i).getUserThreads().size() != games.get(i).getMax()) {
					hasSpace = true;
				}
			}
		}
		
		if(!gameExists) {
			jgr.setExists(false);
			st.receiveJoinGame(jgr);
		}
		else {
			jgr.setExists(true);
			
			if(hasSpace) {
				System.out.println(java.time.LocalTime.now() + " " + jgr.getUser().getName() + " - successfully joined game " + jgr.getName());
				jgr.setSpace(true);
				st.receiveJoinGame(jgr);
			}
			else {
				System.out.println(java.time.LocalTime.now() + " " + jgr.getName() + " exists, but " + jgr.getUser().getName() + " unable to join"
						+ " because maximum number of players have already joined " + jgr.getName());
				jgr.setSpace(false);
				st.receiveJoinGame(jgr);
			}
		}
	}
	
	public void login(ServerThread st, LogInRequest lr) {
		try {
			System.out.println(LocalTime.now() + " " + lr.getUsername() + " - trying to log in with password " + lr.getPassword());
			
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(parameters.get("DBConnection") + "?user=" + 
					parameters.get("DBUsername") + "&password=" + 
					parameters.get("DBPassword") + "&allowPublicKeyRetrieval=true&useSSL=false");
				
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM accounts WHERE username = '" + lr.getUsername() + "'");
			ResultSet rs = ps.executeQuery();
			
			String password = null;
			int wins = 0;
			int losses = 0;
			
			if(rs.next()) {
				password = rs.getString("password");
				wins = rs.getInt("wins");
				losses = rs.getInt("losses");
			}
			if(password != null) {
				if(password.equals(lr.getPassword())) {
					System.out.println(LocalTime.now() + " " + lr.getUsername() + " - successfully logged in.");
					lr.setLogInVal(0);
					lr.setWins(wins);
					lr.setLosses(losses);
					System.out.println(LocalTime.now() + " " + lr.getUsername() + " - has record " + wins + " wins and " + losses + " losses.");
					st.receiveLogin(lr);
				}
				else {
					System.out.println(LocalTime.now() + " " + lr.getUsername() + " - has an account but not successfully logged in.");
					lr.setLogInVal(2);
					st.receiveLogin(lr);
				}
			}
			else {
				System.out.println(java.time.LocalTime.now() + " " + lr.getUsername() + " - does not have account so not successfully logged in.");
				lr.setLogInVal(1);
				st.receiveLogin(lr);
			}
		} 
		catch (ClassNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		} 
		catch (SQLException sqle) {
			System.out.println(sqle.getMessage());
		} 
	}
	
	public void signup(ServerThread st, SignUpRequest sr) {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection conn = DriverManager.getConnection(parameters.get("DBConnection") + "?user=" + 
					parameters.get("DBUsername") + "&password=" + 
					parameters.get("DBPassword") + "&allowPublicKeyRetrieval=true&useSSL=false");
				
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM accounts WHERE username = '" + sr.getUsername() + "'");
			ResultSet rs = ps.executeQuery();
			
			if(rs.next()) {
				// User already exists
				sr.setSignUpVal(1);
				st.receiveSignUp(sr);
			}
			else {
				ps = conn.prepareStatement("INSERT INTO accounts (username, password, wins, losses) values (?, ?, ?, ?)");
				ps.setString(1, sr.getUsername());
				ps.setString(2, sr.getPassword());
				ps.setInt(3, 0);
				ps.setInt(4, 0);
				ps.execute();
				
				System.out.println(LocalTime.now() + " " + sr.getUsername() + " - created an account with password " + sr.getPassword());
				sr.setSignUpVal(0);
				st.receiveSignUp(sr);
			}
		}
		catch (ClassNotFoundException cnfe) {
			System.out.println(cnfe.getMessage());
		}
		catch (SQLException sqle) {
			System.out.println(sqle.getMessage());
		} 
	}
	
	public static void main(String [] args) {
		// Read in the configuration file
		readConfig();

		// Create the server for the program
		new HangmanServer(Integer.parseInt(parameters.get("ServerPort")));
	}

	@SuppressWarnings("resource")
	private static void readConfig() {
		Scanner scan = new Scanner(System.in);
		boolean validConfig = false;
		String configFile = null;
		
		while(!validConfig) {
			try {
				// Read in the name of a configuration file based on user input
				System.out.println("Please enter the name of a configuration file.");
				configFile = scan.nextLine();
				
				System.out.println("Reading config file...");
				
				BufferedReader in = new BufferedReader(new FileReader(configFile));
				
				ArrayList<String> expectedKeys = new ArrayList<String>();
				ArrayList<String> expectedValues = new ArrayList<String>();
				
				expectedKeys.add("ServerHostname");
				expectedKeys.add("ServerPort");
				expectedKeys.add("DBConnection");
				expectedKeys.add("DBUsername");
				expectedKeys.add("DBPassword");
				expectedKeys.add("SecretWordFile");
				
				for(int i = 0; i < expectedKeys.size(); i++) {
					expectedValues.add(null);
				}
				
				String line = in.readLine();
				
				while(line != null) {
					String[] params = line.split("=");
					
					if(params[0] != null && params[1] != null) {
						int index = expectedKeys.indexOf(params[0]);
						expectedValues.add(index, params[1]);
						expectedValues.remove(index + 1);
					}
					
					line = in.readLine();
				}
				
				for(int i = 0; i < expectedKeys.size(); i++) {
					if(expectedValues.get(i) == null) {
						System.out.println(expectedKeys.get(i) + " is a required parameter in the configuration file.");
						String value = scan.nextLine();
						expectedValues.add(i, value);
						expectedValues.remove(i + 1);
					}
					printParameters(expectedKeys.get(i), expectedValues.get(i));
					parameters.put(expectedKeys.get(i), expectedValues.get(i));
				}
				
				validConfig = true;
				
				// Connect to database
				Connection conn = null;
				PreparedStatement ps = null;
	
				// Check if connection succeeded
				try {
					Class.forName("com.mysql.jdbc.Driver");
					System.out.print("\nTrying to connect to database...");
					conn = DriverManager.getConnection(parameters.get("DBConnection") + "?user=" + 
					parameters.get("DBUsername") + "&password=" + 
					parameters.get("DBPassword") + "&allowPublicKeyRetrieval=true&useSSL=false");
					System.out.println("Connected!\n");
				}
				catch(SQLException sqle) {
					System.out.println("Unable to connect to database " + 
							parameters.get("DBConnection") + " with username " + 
							parameters.get("DBUsername") + " and password " +
							parameters.get("DBPassword") + ".");
				} 
				catch (ClassNotFoundException cnfe) {
					System.out.println(cnfe.getMessage());
				}
				finally {
					try {
						if(ps != null) {
							ps.close();
						}
						if(conn != null) {
							conn.close();
						}
					}
					catch (SQLException sqle) {
						System.out.println("sqle closing conn: " + sqle.getMessage());
					}
				}
			}
			catch (FileNotFoundException fnfe) {
				System.out.println("Configuration file " + configFile + " could not be found.");
			}
			catch (IOException ioe) {
				System.out.println(ioe.getMessage());
			}
		}
	}

	private static void printParameters(String key, String value) {
		if(key.equals("ServerHostname")) {
			System.out.println("Server Hostname - " + value);
		}
		else if(key.equals("ServerPort")) {
			System.out.println("Server Port - " + value);
		}
		else if(key.equals("DBConnection")) {
			System.out.println("Database Connection String - " + value);
		}
		else if(key.equals("DBUsername")) {
			System.out.println("Database Username - " + value);
		}
		else if(key.equals("DBPassword")) {
			System.out.println("Database Password - " + value);
		}
		else {
			System.out.println("Secret Word File - " + value);
		}
	}
}
