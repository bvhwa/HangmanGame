package server;

import java.io.EOFException;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.net.Socket;

import classes.GuessRequest;
import classes.JoinGameRequest;
import classes.LoadGameRequest;
import classes.LogInRequest;
import classes.Result;
import classes.SignUpRequest;
import classes.StartGameRequest;
import classes.Turn;
import classes.User;
import classes.Waiting;

public class ServerThread extends Thread {
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private HangmanServer hs;
	private volatile User user;
	private volatile boolean playing = true;
	
	public ServerThread(Socket s, HangmanServer hs) {
		this.hs = hs;
		try {
			oos = new ObjectOutputStream(s.getOutputStream());
			ois = new ObjectInputStream(s.getInputStream());
			this.start();
		}
		catch (IOException ioe) {
			System.out.println("ioe: " + ioe.getMessage());
		}
	}
	public void receiveLogin(LogInRequest lr) {
		try {
			oos.writeObject(lr);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void receiveSignUp(SignUpRequest sr) {
		try {
			oos.writeObject(sr);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void receiveStartGame(StartGameRequest sgr) {
		try {
			oos.writeObject(sgr);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void receiveJoinGame(JoinGameRequest jgr) {
		try {
			oos.writeObject(jgr);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void receiveWaiting(Waiting w) {
		try {
			oos.writeObject(w);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void sendUser(User user) {
		try {
			oos.writeObject(user);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void receiveGuessRequest(GuessRequest gr) {
		try {
			oos.writeObject(gr);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void updateTurn(Turn turn) {
		try {
			oos.writeObject(turn);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void sendResult(Result result) {
		try {
			oos.reset();
			oos.writeObject(result);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void run() {
		while(playing) {
			try {
				Object o = ois.readObject();
					
				if(o instanceof LogInRequest) {
					LogInRequest lr = (LogInRequest)o;
					hs.login(this, lr);
				}
				if(o instanceof SignUpRequest) {
					SignUpRequest sr = (SignUpRequest)o;
					hs.signup(this, sr);
				}
				if(o instanceof StartGameRequest) {
					StartGameRequest sgr = (StartGameRequest)o;
					
					this.setUser(sgr.getUser());
					
					if(sgr.getUsers() == 0) {
						hs.start(this, sgr);
					}
					else {
						hs.initStart(this, sgr);
					}
				}
				if(o instanceof JoinGameRequest) {
					JoinGameRequest jgr = (JoinGameRequest)o;
					
					this.setUser(jgr.getUser());
					
					if(jgr.isExists() && jgr.isSpace()) {
						hs.initJoin(this, jgr);
					}
					else {
						hs.join(this, jgr);
					}
				}
				if(o instanceof LoadGameRequest) {
					hs.loadGame(this);
				}
				if(o instanceof GuessRequest) {
					GuessRequest gr = (GuessRequest)o;
					if(gr.isGuessType()) {
						hs.guessWord(this, gr);
					}
					else {
						hs.guessChar(this, gr);
					}
				}
			}
			catch (ClassNotFoundException cnfe) {
				System.out.println("st cnfe in run: " + cnfe.getMessage());
			}
			catch (EOFException eofe) {
				break;
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public boolean isPlaying() {
		return playing;
	}
	public void setPlaying(boolean playing) {
		this.playing = playing;
	}
}