package client;

import java.io.BufferedReader;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

import java.net.Socket;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

import classes.GuessRequest;
import classes.JoinGameRequest;
import classes.LoadGameRequest;
import classes.LogInRequest;
import classes.Result;
import classes.SignUpRequest;
import classes.StartGameRequest;
import classes.Turn;
import classes.User;
import classes.Waiting;

public class HangmanClient extends Thread {
	private ObjectOutputStream oos;
	private ObjectInputStream ois;
	private Scanner scan = new Scanner(System.in);
	private volatile boolean loggedIn = false;
	private volatile boolean waiting = true;
	private volatile boolean playing = true;
	private User user;
	
	public HangmanClient(String hostname, int port) {
		Socket s = null;
		
		try {
			System.out.print("\nTrying to connect to server...");
			s = new Socket(hostname, port);
			System.out.println("Connected!\n");
			ois = new ObjectInputStream(s.getInputStream());
			oos = new ObjectOutputStream(s.getOutputStream());
			this.start();
			
			while(playing) {
				this.login();
				while(!loggedIn) {}
				
				this.gameOptions();
				while(waiting) {}
				
				this.play();
				while(playing) {}
			}
		}
		catch (IOException ioe) {
			System.out.println("Unable to connect to server " + hostname + " on port " + port);
		}
		finally {
			try {
				if(s != null) {
					s.close();
				}
			}
			catch (IOException ioe) {
				System.out.println("ioe closing stuff: " + ioe.getMessage());
			}
		}
	}
	
	public void play() {
		try {
			System.out.println("Determining secret word...\n");
			LoadGameRequest lgr = new LoadGameRequest();
			oos.writeObject(lgr);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void gameOptions() {
		System.out.println("1) Start a Game");
		System.out.println("2) Join a Game \n");
		System.out.println("Would you like to start a game or join a game?");
		
		String option = scan.nextLine();
		
		while(!(option.equals("1") || option.equals("2")))
		{
			System.out.println("Would you like to start a game or join a game?");
			option = scan.nextLine();
		}
		if(option.equals("1")) {
			this.startGame();
		}
		if(option.equals("2")) {
			this.joinGame();
		}
	}
	
	public void startGame() {
		try {
			System.out.println("What is the name of the game?");
			String name = scan.nextLine();
			StartGameRequest sgr = new StartGameRequest(name, this.user);
			oos.writeObject(sgr);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void joinGame() {
		try {
			System.out.println("What is the name of the game?");
			String name = scan.nextLine();
			JoinGameRequest jgr = new JoinGameRequest(name, this.user);
			oos.writeObject(jgr);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void login() {
		try {
			System.out.print("Username: ");
			String username = scan.nextLine();
			System.out.print("Password: ");
			String password = scan.nextLine();
			
			LogInRequest lr = new LogInRequest(username, password);
			oos.writeObject(lr);
			oos.flush();
		} 
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void signup() {
		try {
			System.out.print("New Username: ");
			String username = scan.nextLine();
			System.out.println("New Password: ");
			String password = scan.nextLine();
			
			SignUpRequest sr = new SignUpRequest(username, password);
			oos.writeObject(sr);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}
	
	public void run() {
		while(playing) {
			try {
				Object o = ois.readObject();
				
				if(o instanceof LogInRequest) {
					LogInRequest lr = (LogInRequest)o;
					this.parseLogInRequest(lr);
				}
				if(o instanceof SignUpRequest) {
					SignUpRequest sr = (SignUpRequest)o;
					this.parseSignUpRequest(sr);
				}
				if(o instanceof StartGameRequest) {
					StartGameRequest sgr = (StartGameRequest)o;
					this.parseStartGameRequest(sgr);
				}
				if(o instanceof JoinGameRequest) {
					JoinGameRequest jgr = (JoinGameRequest)o;
					this.parseJoinGameRequest(jgr);
				}
				if(o instanceof Waiting) {
					Waiting w = (Waiting)o;
					this.parseWaiting(w);
				}
				if(o instanceof User) {
					User user = (User)o;
					this.displayStats(user);
				}
				if(o instanceof Turn) {
					Turn turn = (Turn)o;
					this.doTurn(turn);
				}
				if(o instanceof GuessRequest) {
					GuessRequest gr = (GuessRequest)o;
					this.parseGuessRequest(gr);
				}
				if(o instanceof Result) {
					Result result = (Result)o;
					this.parseResult(result);
				}
			}
			catch (IOException ioe) {
				System.out.println("hc ioe in run: " + ioe.getMessage());
				ioe.printStackTrace();
			} 
			catch (ClassNotFoundException cnfe) {
				System.out.println("hc cnfe in run:" + cnfe.getMessage());
			}
		}
		
	}
	
	private void parseResult(Result result) {
		if(result.getWinner() == null) {
			User user = null;
			
			for(int i = 0; i < result.getPlayers().size(); i++) {
				if(result.getPlayers().get(i).getName().equals(this.user.getName())) {
					user = result.getPlayers().get(i);
				}
			}
			this.displayStats(user);
			
			for(int i = 0; i < result.getPlayers().size(); i++) {
				if(!result.getPlayers().get(i).getName().equals(this.user.getName())) {
					this.displayStats(result.getPlayers().get(i));
				}
			}
			
			System.out.println("Thank you for playing Hangman!");
		}
		else {
			if(result.getWinner().getName().equals(this.user.getName())) {
				System.out.println("That is correct! You win!");
				
				User user = null;
				
				for(int i = 0; i < result.getPlayers().size(); i++) {
					if(result.getPlayers().get(i).getName().equals(this.user.getName())) {
						user = result.getPlayers().get(i);
					}
				}
				this.displayStats(user);
				
				for(int i = 0; i < result.getPlayers().size(); i++) {
					if(!result.getPlayers().get(i).getName().equals(this.user.getName())) {
						this.displayStats(result.getPlayers().get(i));
					}
				}
				
				System.out.println("Thank you for playing Hangman!");
			}
			else {
				System.out.println(result.getWinner().getName() + " guessed the word correctly! You lose!");

				User user = null;
				
				for(int i = 0; i < result.getPlayers().size(); i++) {
					if(result.getPlayers().get(i).getName().equals(this.user.getName())) {
						user = result.getPlayers().get(i);
					}
				}
				this.displayStats(user);
				
				for(int i = 0; i < result.getPlayers().size(); i++) {
					if(!result.getPlayers().get(i).getName().equals(this.user.getName())) {
						this.displayStats(result.getPlayers().get(i));
					}
				}
				
				System.out.println("Thank you for playing Hangman!");
			}
		}
		playing = false;
	}

	private void parseGuessRequest(GuessRequest gr) {
		if(!gr.getUser().getName().equals(this.user.getName())) {
			if(gr.isGuessType()) {
				System.out.print(gr.getUser().getName() + " guessed the word incorrectly and is now out of the game. \n");
			}
			else {
				System.out.println(gr.getUser().getName() + " has guessed letter " + gr.getGuess() +"\n");
				
				if(gr.isContains()) {
					System.out.println("The letter " + gr.getGuess() + " is in the secret word.\n");
				}
				else {
					System.out.println("The letter " + gr.getGuess() + " is not in the secret word.\n");
				}
			}
		}
		else {
			if(gr.isGuessType()) {
				if(!gr.isContains()) {
					System.out.println("That is incorrect! You lose!");
					System.out.println("The word was \"" + gr.getSecret() + "\".\n");
				}
			}
			else {
				if(gr.isContains()) {
					System.out.println("The letter " + gr.getGuess() + " is in the secret word.\n");
				}
				else {
					System.out.println("The letter " + gr.getGuess() + " is not in the secret word.\n");
				}
			}
		}
	}

	private void doTurn(Turn turn) {
		System.out.print("Secret Word: ");
		for(int i = 0; i < turn.getSecret().length(); i++) {
			boolean found = false;
			for(int j = 0; j < turn.getGuesses().size(); j++) {
				if(turn.getSecret().substring(i, i+1).equals(turn.getGuesses().get(j))){
					System.out.print(turn.getGuesses().get(j).toUpperCase() + " ");
					found = true;
				}
			}
			if(!found) {
				System.out.print("_ ");
			}
		}
		
		System.out.println("\n");
		
		if(turn.getPlayer().getName().equals(this.user.getName())) {
			System.out.println("You have " + turn.getNumGuesses() + " incorrect guesses remaining.");
			System.out.println("1) Guess a letter.");
			System.out.println("2) Guess the word.");
			System.out.println("\nWhat would you like to do?");
			
			String option = null;
			option = scan.nextLine();
			
			while(!option.equals("1") && !option.equals("2")) {
				System.out.println("That is not a valid option.");
				System.out.println("\nWhat would you like to do?");
				option = scan.nextLine();
			}
			
			if(option.equals("1")) {
				this.guessLetter();
			}
			else {
				this.guessWord();
			}
		}
		else {
			System.out.println("You have " + turn.getNumGuesses() + " incorrect guesses remaining.");
			System.out.println("Waiting for " + turn.getPlayer().getName() + " to do something...\n\n\n");
		}
	}
	
	private void guessLetter() {
		try {
			System.out.print("Letter to guess - ");
			String letter = scan.nextLine();
			System.out.println("");
			GuessRequest gr = new GuessRequest(letter, this.user, false);
			oos.writeObject(gr);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	private void guessWord() {
		try {
			System.out.println("What is the secret word?");
			String word = scan.nextLine();
			System.out.println("");
			GuessRequest gr = new GuessRequest(word, this.user, true);
			oos.writeObject(gr);
			oos.flush();
		}
		catch (IOException ioe) {
			ioe.printStackTrace();
		}
	}

	private void parseWaiting(Waiting w) {
		if(w.getWaitingFor() == 0) {
			System.out.println("All users have joined.\n");
			waiting = false;
		}
		else if(w.getWaitingFor() == 1) {
			System.out.println("Waiting for " + w.getWaitingFor() + " other user to join...");
		}
		else {
			System.out.println("Waiting for " + w.getWaitingFor() + " other users to join...");
		}
	}
	
	private void parseStartGameRequest(StartGameRequest sgr) {
		if(sgr.isExists()) {
			this.startGame();
		}
		else {
			this.setUsers(sgr);
		}
	}
	
	private void setUsers(StartGameRequest sgr) {
		int users = 0;
		
		while(users == 0) {
			System.out.println("How many users will be playing (1-4)?");
			String numUsers = scan.nextLine();
			
			switch(numUsers) {
			case "1": users = 1;
				break;
			case "2": users = 2;
				break;
			case "3": users = 3;
				break;
			case "4": users = 4;
				break;
			default: users = 0;
				break;
			}
			
			if(users == 0) {
				System.out.println("A game can only have between 1-4 players.");
			}
		}

		try {
			sgr.setUsers(users);
			oos.writeObject(sgr);
			oos.flush();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	private void parseJoinGameRequest(JoinGameRequest jgr) {
		if(jgr.isExists()) {
			if(jgr.isSpace()) {
				try {
					oos.writeObject(jgr);
					oos.flush();
				} 
				catch (IOException e) {
					e.printStackTrace();
				}
			}
			else {
				System.out.println("The game " + jgr.getName() + " does not have space for another user to join.");
				this.joinGame();
			}
		}
		else {
			System.out.println("There is no game with name " + jgr.getName());
			this.joinGame();
		}
	}
	
	private void displayStats(User user) {		
		if(user.isPlaying()) {
			System.out.println("\nUser " + user.getName() + " is in the game.");
		}
		System.out.println("\n" + user.getName() + "'s Record");
		System.out.println("-------------");
		System.out.println("Wins - " + user.getWins());
		System.out.println("Losses - " + user.getLosses() + "\n");
	}
	
	private void parseSignUpRequest(SignUpRequest sr) {
		if(sr.getSignUpVal() == 0) {
			System.out.println("Signed up!");
			
			User user = new User(sr.getUsername(), 0, 0);
			this.user = user;
			
			loggedIn = true;
		}
		else {
			System.out.println("Username already exists!");
			this.signup();
		}
	}
	
	private void parseLogInRequest(LogInRequest lr) {
		if(lr.getLogInVal() == 0) {
			System.out.println("\nGreat! You are now logged in as " + lr.getUsername() + "!\n");
			System.out.println(lr.getUsername() + "'s Record");
			System.out.println("--------------");
			System.out.println("Wins - " + lr.getWins());
			System.out.println("Losses - " + lr.getLosses() + "\n");
			
			this.user = new User(lr.getUsername(), lr.getWins(), lr.getLosses());

			loggedIn = true;
		}
		else if(lr.getLogInVal() == 1) {
			System.out.println("No account exists with those credentials.");
			System.out.println("Would you like to create an account?");
			
			if(scan.nextLine().toLowerCase().equals("yes")) {
				this.signup();
			}
			else {
				this.login();
			}
		}
		else {
			System.out.println("Incorrect password.");
			this.login();
		}
	}
	
	public static void main(String [] args) {
		HashMap<String, String> parameters = new HashMap<String, String>();
		
		readConfig(parameters);
		
		new HangmanClient(parameters.get("ServerHostname"), Integer.parseInt(parameters.get("ServerPort")));
	}

	@SuppressWarnings("resource")
	private static void readConfig(HashMap<String,String> parameters) {
		Scanner scan = new Scanner(System.in);
		boolean validConfig = false;
		String configFile = null;
		
		while(!validConfig) {
			try {
				// Read in the name of a configuration file based on user input
				System.out.println("Please enter the name of a configuration file.");
				configFile = scan.nextLine();
				
				System.out.println("Reading config file...");
				
				BufferedReader in = new BufferedReader(new FileReader(configFile));
				
				ArrayList<String> expectedKeys = new ArrayList<String>();
				ArrayList<String> expectedValues = new ArrayList<String>();
				
				expectedKeys.add("ServerHostname");
				expectedKeys.add("ServerPort");
				expectedKeys.add("DBConnection");
				expectedKeys.add("DBUsername");
				expectedKeys.add("DBPassword");
				expectedKeys.add("SecretWordFile");
				
				for(int i = 0; i < expectedKeys.size(); i++) {
					expectedValues.add(null);
				}
				
				String line = in.readLine();
				
				while(line != null) {
					String[] params = line.split("=");
					
					if(params[0] != null && params[1] != null) {
						int index = expectedKeys.indexOf(params[0]);
						expectedValues.add(index, params[1]);
						expectedValues.remove(index + 1);
					}
					
					line = in.readLine();
				}
				
				for(int i = 0; i < expectedKeys.size(); i++) {
					if(expectedValues.get(i).equals(null)) {
						System.out.println(expectedKeys.get(i) + " is a required parameter in the configuration file.");
						String value = scan.nextLine();
						expectedValues.add(i, value);
						expectedValues.remove(i);
					}
					printParameters(expectedKeys.get(i), expectedValues.get(i));
					parameters.put(expectedKeys.get(i), expectedValues.get(i));
				}
				
				validConfig = true;
			}
			catch (FileNotFoundException fnfe) {
				System.out.println("Configuration file " + configFile + " could not be found.");
			}
			catch (IOException ioe) {
				System.out.println(ioe.getMessage());
			}
		}
	}

	private static void printParameters(String key, String value) {
		if(key.equals("ServerHostname")) {
			System.out.println("Server Hostname - " + value);
		}
		else if(key.equals("ServerPort")) {
			System.out.println("Server Port - " + value);
		}
		else if(key.equals("DBConnection")) {
			System.out.println("Database Connection String - " + value);
		}
		else if(key.equals("DBUsername")) {
			System.out.println("Database Username - " + value);
		}
		else if(key.equals("DBPassword")) {
			System.out.println("Database Password - " + value);
		}
		else {
			System.out.println("Secret Word File - " + value);
		}
	}
}
