package classes;

import java.util.Vector;

import server.ServerThread;

public class Game {
	private String name;
	private int max;
	private Vector<ServerThread> userThreads = new Vector<ServerThread>();
	private Vector<String> guesses = new Vector<String>();
	private volatile boolean ready = false;
	private volatile boolean loaded = false;
	private String secret;
	private int numGuesses = 7;
	
	public Game(String name, int max) {
		this.setName(name);
		this.setMax(max);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Vector<ServerThread> getUserThreads() {
		return userThreads;
	}

	public void setUserThreads(Vector<ServerThread> userThreads) {
		this.userThreads = (Vector<ServerThread>) userThreads.clone();
	}

	public int getMax() {
		return max;
	}

	public void setMax(int max) {
		this.max = max;
	}

	public boolean isReady() {
		return ready;
	}

	public void setReady(boolean ready) {
		this.ready = ready;
	}

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}

	public boolean isLoaded() {
		return loaded;
	}

	public void setLoaded(boolean loaded) {
		this.loaded = loaded;
	}

	public Vector<String> getGuesses() {
		return guesses;
	}

	public void setGuesses(Vector<String> guesses) {
		this.guesses = (Vector<String>) guesses.clone();
	}

	public int getNumGuesses() {
		return numGuesses;
	}

	public void setNumGuesses(int numGuesses) {
		this.numGuesses = numGuesses;
	}
}
