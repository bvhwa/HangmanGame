package classes;

import java.io.Serializable;

public class GuessRequest implements Serializable {
	private static final long serialVersionUID = 1;
	private String guess;
	private User user;
	// false = character, true = word
	private boolean guessType;
	// false = guess not correct, true = guess correct
	private boolean contains;
	private String secret;
	
	public GuessRequest(String guess, User user, boolean guessType) {
		this.setGuess(guess);
		this.setUser(user);
		this.setGuessType(guessType);
	}

	public String getGuess() {
		return guess;
	}

	public void setGuess(String guess) {
		this.guess = guess;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public boolean isGuessType() {
		return guessType;
	}

	public void setGuessType(boolean guessType) {
		this.guessType = guessType;
	}

	public boolean isContains() {
		return contains;
	}

	public void setContains(boolean contains) {
		this.contains = contains;
	}

	public String getSecret() {
		return secret;
	}

	public void setSecret(String secret) {
		this.secret = secret;
	}
}
