package classes;

import java.io.Serializable;

public class LoadGameRequest implements Serializable {
	private static final long serialVersionUID = 1;
	
	public LoadGameRequest() {
		super();
	}
}
