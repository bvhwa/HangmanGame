package classes;

import java.io.Serializable;
import java.util.Vector;

public class Turn implements Serializable {
	private static final long serialVersionUID = 1;
	private String secret;
	private User player;
	private int numGuesses = 7;
	private Vector<String> guesses = new Vector<String>();
	
	public Turn(User user, Vector<String> guesses) {
		this.setPlayer(user);
		this.setGuesses(guesses);
	}
	
	public String getSecret() {
		return secret;
	}
	public void setSecret(String secret) {
		this.secret = secret;
	}
	public int getNumGuesses() {
		return numGuesses;
	}
	public void setNumGuesses(int numGuesses) {
		this.numGuesses = numGuesses;
	}
	public Vector<String> getGuesses() {
		return guesses;
	}
	public void setGuesses(Vector<String> guesses) {
		this.guesses = (Vector<String>) guesses.clone();
	}
	public User getPlayer() {
		return player;
	}
	public void setPlayer(User player) {
		this.player = player;
	}
}
