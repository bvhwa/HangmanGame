package classes;

import java.io.Serializable;
import java.util.Vector;

public class Result implements Serializable {
	private static final long serialVersionUID = 1;
	private User winner;
	private Vector<User> players = new Vector<User>();
	
	public Result(User user) {
		this.setWinner(user);
	}
	
	public User getWinner() {
		return winner;
	}
	public void setWinner(User winner) {
		this.winner = winner;
	}
	public Vector<User> getPlayers() {
		return players;
	}
	public void setPlayers(Vector<User> players) {
		this.players = players;
	}
}
