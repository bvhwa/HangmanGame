package classes;

import java.io.Serializable;

public class JoinGameRequest implements Serializable {
	private static final long serialVersionUID = 1;
	private String name;
	private User user;
	private boolean exists = false;
	private boolean space = false;
	
	public JoinGameRequest(String name, User user) {
		this.setName(name);
		this.setUser(user);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	public boolean isExists() {
		return exists;
	}

	public void setExists(boolean exists) {
		this.exists = exists;
	}

	public boolean isSpace() {
		return space;
	}

	public void setSpace(boolean space) {
		this.space = space;
	}
}
