package classes;

import java.io.Serializable;

public class LogInRequest implements Serializable {
	private static final long serialVersionUID = 1;
	private String username;
	private String password;
	private int wins;
	private int losses;
	private int logInVal;

	public LogInRequest(String user, String pass) {
		this.setUsername(user);
		this.setPassword(pass);
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getWins() {
		return wins;
	}

	public void setWins(int wins) {
		this.wins = wins;
	}

	public int getLosses() {
		return losses;
	}

	public void setLosses(int losses) {
		this.losses = losses;
	}

	public int getLogInVal() {
		return logInVal;
	}

	public void setLogInVal(int logInVal) {
		this.logInVal = logInVal;
	}
}
