package classes;

import java.io.Serializable;

public class User implements Serializable {
	private static final long serialVersionUID = 1;
	private String name;
	private int wins;
	private int losses;
	private boolean host = false;
	private volatile boolean turn = false;
	private volatile boolean playing = true;
	
	public User(String name, int wins, int losses) {
		this.setName(name);
		this.setWins(wins);
		this.setLosses(losses);
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getWins() {
		return wins;
	}
	public void setWins(int wins) {
		this.wins = wins;
	}
	public int getLosses() {
		return losses;
	}
	public void setLosses(int losses) {
		this.losses = losses;
	}

	public boolean isHost() {
		return host;
	}

	public void setHost(boolean host) {
		this.host = host;
	}

	public boolean isTurn() {
		return turn;
	}

	public void setTurn(boolean turn) {
		this.turn = turn;
	}

	public boolean isPlaying() {
		return playing;
	}

	public void setPlaying(boolean playing) {
		this.playing = playing;
	}
}
