package classes;

import java.io.Serializable;

public class Waiting implements Serializable {
	private static final long serialVersionUID = 1;
	private int waitingFor;

	public int getWaitingFor() {
		return waitingFor;
	}

	public void setWaitingFor(int waitingFor) {
		this.waitingFor = waitingFor;
	}
}
