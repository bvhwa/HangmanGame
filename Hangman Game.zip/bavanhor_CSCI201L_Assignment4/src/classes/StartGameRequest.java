package classes;

import java.io.Serializable;

public class StartGameRequest implements Serializable {
	private static final long serialVersionUID = 1;
	// Name of the game
	private String name = null;
	// Whether the game exists
	private boolean exists = false;
	private int users = 0;
	private User user;
	
	public StartGameRequest(String name, User user) {
		this.setName(name);
		this.setUser(user);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isExists() {
		return exists;
	}

	public void setExists(boolean exists) {
		this.exists = exists;
	}

	public int getUsers() {
		return users;
	}

	public void setUsers(int users) {
		this.users = users;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}
}
